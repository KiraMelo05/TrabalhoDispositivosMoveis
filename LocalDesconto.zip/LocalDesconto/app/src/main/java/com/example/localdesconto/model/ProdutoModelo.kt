package com.example.localdesconto.model

data class ProdutoModelo(

    val foto: Int,
    val nome: String,
    val descricao: String,
    val preco: String
)