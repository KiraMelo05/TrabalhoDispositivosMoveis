package com.example.localdesconto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.localdesconto.adapter.AdapterProduto
import com.example.localdesconto.model.ProdutoModelo

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView_produtos = findViewById<RecyclerView>(R.id.recyclerView_produtos)
        recyclerView_produtos.layoutManager = LinearLayoutManager(this)
        recyclerView_produtos.setHasFixedSize(true)
        val listaprodutos : MutableList<ProdutoModelo> = mutableListOf()
        val adapterProduto = AdapterProduto(this,listaprodutos)
        recyclerView_produtos.adapter = adapterProduto
        val produto1 = ProdutoModelo(
            R.drawable.bmx,
            "Bicicleta BMX" ,
        "Manobras Radicais Com Sua BMX CUPOM: BMX23",
            "de R\$ 1800 por R\$ 1500"
        )
        listaprodutos.add(produto1)

        val produto2 = ProdutoModelo(
            R.drawable.gabinete,
            "Gabinete computador",
            "A série Carbide SPEC-DELTA RGB é uma caixa ATX de torre média de vidro temperado CUPOM GABINETE55",
            "de R\$ 1200 por R\$ 500",
        )
        listaprodutos.add(produto2)

        val produto3 = ProdutoModelo(
            R.drawable.memoria,
            "Memória DDR4",
            "Memória DDR4 3200 MHZ CUPOM: MEMORIA424",
            "de R\$300 por R\$ 150,
        )
        listaprodutos.add(produto3)
    }
}